<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "student".
 *
 * @property integer $id
 * @property string $lastname
 * @property string $firstname
 * @property string $middlename
 * @property string $nickname
 * @property string $gender
 * @property string $email_address
 * @property integer $contact_number
 * @property string $address
 * @property string $school
 * @property string $school_address
 * @property string $guardian_name
 * @property integer $gcontact_number
 * @property integer $gemail_address
 * @property string $date
 *
 * @property Account $id0
 */
class Student extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'student';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    { //'unique', 'targetClass' => '\common\models\User', 'message' => 'This email address has already been taken.'],
        return [
            [['lastname', 'firstname', 'nickname', 'gender', 'email_address', 'contact_number', 'address', 'school', 'school_address', 'guardian_name', 'gcontact_number'], 'required'],
            [['contact_number', 'gcontact_number', 'gemail_address'], 'integer'],
            [['date'], 'safe'],
            [['lastname', 'firstname', 'middlename'], 'string', 'max' => 30],
            [['nickname'], 'string', 'max' => 15],
            [['gender'], 'string', 'max' => 7],
            [['email_address', 'address', 'school'], 'string', 'max' => 45],
			[['email_address','unique', 'targetClass' => '\common\models\Student', 'message' => 'This email address has already been taken.'],
            [['school_address'], 'string', 'max' => 50],
            [['guardian_name'], 'string', 'max' => 60],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => Account::className(), 'targetAttribute' => ['id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'lastname' => 'Lastname',
            'firstname' => 'Firstname',
            'middlename' => 'Middlename',
            'nickname' => 'Nickname',
            'gender' => 'Gender',
            'email_address' => 'Email Address',
            'contact_number' => 'Contact Number',
            'address' => 'Address',
            'school' => 'School',
            'school_address' => 'School Address',
            'guardian_name' => 'Guardian Name',
            'gcontact_number' => 'Gcontact Number',
            'gemail_address' => 'Gemail Address',
            'date' => 'Date',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(Account::className(), ['id' => 'id']);
    }
}
