<br><br><br><br><br>
           <div class="row" >   
               
                 <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.4s">
                     <div class="about-div">
                     <i class="fa fa-book fa-4x icon-round-border" ></i>
                   <h3 >TRANSACTIONS</h3>
                 <hr />
                       <hr />
                   <p >
                       Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                        Aenean commodo . 
                       
                   </p>
              <a href="http://localhost/advancedlsc2/frontend/web/index.php?r=site%2Faccount" class="btn btn-info btn-set"  >VIEW TRANSACTIONS</a>
                </div>
                   </div>

 <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.6s">
                     <div class="about-div">
                     <i class="fa fa-plus fa-4x icon-round-border" ></i>
                   <h3 >ADD TRANSACTION</h3>
                 <hr />
                       <hr />
                   <p >
                       Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                        Aenean commodo . 
                       
                   </p>

              <a href="http://localhost/advancedlsc2/frontend/web/index.php?r=site%2Faccount" class="btn btn-info btn-set"  >ADD TRANSACTION</a>

                </div>
                   </div>
                   
                   <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.5s">
                     <div class="about-div">
                     <i class="fa fa-cog fa-4x icon-round-border" ></i>
                   <h3 >RESET PASSWORD</h3>
                 <hr />
                       <hr />
                   <p >
                       Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                        Aenean commodo . 
                   </p>

              <a href="http://localhost/advancedlsc2/frontend/web/index.php?r=site%2Faccount" class="btn btn-info btn-set"  >CONFIGURE</a>

                </div>
                   </div>
                  
               </div>
             </div>