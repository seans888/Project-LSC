<?php
return [
    'adminEmail' => 'dbalcena@gmail.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
];
